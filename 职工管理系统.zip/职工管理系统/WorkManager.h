#pragma once
#include"Employee.h"
#include<vector>
#include<fstream>
class WorkManager {
public:
	vector<Employee*> employees;
	void addWorker(Employee* employee);
	void showWorkers(); 
	void deleteWorker(int id); 
	void modifyWorker(int id, const string& name, int deptId); 
	void findWorkerById(int id) const; 
	void findWorkerByName(const string& name) const; 
	void sortWorkersByID(bool ascending); 
	void sortWorkersByName(bool ascending);
	void clearWorkers();
	void saveToFile(const string& filename) const;
	void loadFromFile(const string& filename);

};
