#pragma once
#include"Employee.h"
using namespace std;
class Worker:public Employee {
public:
	Worker(int id, string name, int deptid):Employee(id,name,deptid){}
	void showInfo() const override;
	string getDeptName()const override;
};
