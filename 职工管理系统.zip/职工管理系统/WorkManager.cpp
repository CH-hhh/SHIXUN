#include"WorkManager.h"
#include "Manager.h"
#include "Boss.h"
#include "Worker.h"
using namespace std;
void WorkManager::addWorker(Employee* employee) {
    employees.push_back(employee);
}
void WorkManager::showWorkers()  {
    // ��յ�ǰԱ���б�
    for (auto& worker : employees) {
        delete worker;
    }
    employees.clear();

    // ��ȡ�ļ��е�����
    std::ifstream inFile("workers.txt");
    if (!inFile) {
        std::cerr << "�޷����ļ����ж�ȡ: workers.txt" << std::endl;
        return;
    }

    int id, deptId;
    std::string name;
    while (inFile >> id >> name >> deptId) {
        if (deptId == 2) {
            employees.push_back(new Manager(id, name, deptId));
        }
        else if (deptId == 3) {
            employees.push_back(new Boss(id, name, deptId));
        }
        else if (deptId == 1) {
            employees.push_back(new Worker(id, name, deptId));
        }
    }

    inFile.close();

    // ��ʾԱ����Ϣ
    for (auto employee : employees) {
        employee->showInfo();
    }
}
void WorkManager::deleteWorker(int id) {
    bool found = false;
    for (auto it = employees.begin(); it != employees.end(); ++it) {
        if ((*it)->getId() == id) {
            delete* it;
            employees.erase(it);
            found = true;
            cout << "ְ����ɾ����" << endl;
            break;
        }
    }
    if (!found) {
        cout << "δ�ҵ���ְ����" << endl;
    }
}
void WorkManager::modifyWorker(int id, const string& name, int deptId) {
    if (name.empty() || deptId <= 0) {
        cout << "��Ч���������ű�š�" << endl;
        return;
    }

    for (auto& employee : employees) {
        if (employee->getId() == id) {
            employee->setName(name);
            employee->setDeptId(deptId);
            cout << "ְ����Ϣ���޸ģ���� " << id << "������ " << name << "�����ű�� " << deptId << "��" << endl;
            saveToFile("workers.txt");
            cout << "ְ����Ϣ�Ѹ��µ��ļ���workers.txt" << endl;

            return;
        }
    }
    cout << "δ�ҵ����Ϊ " << id << " ��ְ����" << endl;
}
void WorkManager::findWorkerById(int id) const {
    for (auto employee : employees) {
        if (employee->getId() == id) {
            employee->showInfo();
            return;
        }
    }
    cout << "δ�ҵ���ְ����" << endl;
}
void WorkManager::findWorkerByName(const string& name) const {
    for (auto employee : employees) {
        if (employee->getName() == name) {
            employee->showInfo();
            return;
        }
    }
    cout << "δ�ҵ���ְ����" << endl;
}
void WorkManager::sortWorkersByID(bool ascending) {
    for (size_t i = 0; i < employees.size(); ++i) {
        for (size_t j = i + 1; j < employees.size(); ++j) {
            if ((ascending && employees[i]->getId() > employees[j]->getId()) || (!ascending && employees[i]->getId() < employees[j]->getId())) {
                swap(employees[i], employees[j]);
            }
        }
    }
}
void WorkManager::sortWorkersByName(bool ascending) {
    for (size_t i = 0; i < employees.size(); ++i) {
        for (size_t j = i + 1; j < employees.size(); ++j) {
            if ((ascending && employees[i]->getName() > employees[j]->getName()) ||
                (!ascending && employees[i]->getName() < employees[j]->getName())) {
                std::swap(employees[i], employees[j]);
            }
        }
    }
}
void WorkManager::clearWorkers() {
    employees.clear();
    cout << "����ְ����Ϣ����ա�" << endl;
}
void WorkManager::saveToFile(const std::string& filename) const {
    std::ofstream outFile(filename);
    if (!outFile) {
        std::cerr << "�޷����ļ�����д��: " << filename << std::endl;
        return;
    }
    for (const auto& worker : employees) {
        outFile << worker->getId() << " " << worker->getName() << " " << worker->getDeptId() << std::endl;
    }
    outFile.close();
}
void WorkManager::loadFromFile(const std::string& filename) {
    std::ifstream inFile(filename);
    if (!inFile) {
        std::cerr << "�޷����ļ����ж�ȡ: " << filename << std::endl;
        return;
    }

    int id, deptId;
    std::string name;

    while (inFile >> id >> name >> deptId) {
        if (deptId == 2) {
            addWorker(new Manager(id, name, deptId));
        }
        else if (deptId == 3) {
            addWorker(new Boss(id, name, deptId));
        }
        else if (deptId == 1) {
            addWorker(new Worker(id, name, deptId));
        }
    }

    inFile.close();
}