#pragma once
#include"Employee.h"
using namespace std;
class Boss :public Employee {
public:
	Boss (int id,string name, int deptid): Employee(id,name,deptid){}
	void showInfo() const override;
	string getDeptName() const override;
};