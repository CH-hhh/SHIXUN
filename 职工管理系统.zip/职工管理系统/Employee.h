#pragma once
#include<iostream>
#include<string>
using namespace std;
class Employee {
protected:
    int id;
    std::string name;
    int deptId;

public:
    Employee(int id, string name, int deptId) : id(id), name(name), deptId(deptId) {}
    int getId() const { return id; }
    int setId(const int id) { this->id = id; }
    string getName() const { return name; }
    void setName(const std::string& name) { this->name = name; }
    int getDeptId() const { return deptId; }
    void setDeptId(int deptId) { this->deptId =deptId; }
    virtual void showInfo() const = 0;
    virtual string getDeptName() const = 0;
    virtual ~Employee() = default;
};